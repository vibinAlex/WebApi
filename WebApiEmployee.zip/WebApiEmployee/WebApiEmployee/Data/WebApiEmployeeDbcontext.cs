﻿using Microsoft.EntityFrameworkCore;
using WebApiEmployee.Models;

namespace WebApiEmployee.Data
{
    public class WebApiEmployeeDbcontext : DbContext
    {
        public WebApiEmployeeDbcontext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Employee> Employees { get; set; } 
    }
}
