﻿namespace WebApiEmployee.Models
{
    public class AddEmployee
    {
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Department { get; set; }
    }
}
