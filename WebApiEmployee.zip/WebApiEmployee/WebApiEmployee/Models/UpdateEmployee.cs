﻿namespace WebApiEmployee.Models
{
    public class UpdateEmployee
    {
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Department { get; set; }
    }
}
