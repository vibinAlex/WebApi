﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApiEmployee.Data;
using WebApiEmployee.Models;

namespace WebApiEmployee.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmloyeesController : Controller
    {
        private readonly WebApiEmployeeDbcontext dbcontext;

        public EmloyeesController(WebApiEmployeeDbcontext dbcontext)
        {
            this.dbcontext = dbcontext;
        }

        [HttpGet]
        public async Task<IActionResult> GetEmloyees()
        {
            return Ok(await dbcontext.Employees.ToListAsync());
        }

        [HttpGet]       
        [Route("{id:guid}")]
        public async Task<IActionResult> GetEmployee([FromRoute] Guid id)
        {
            var employee = await dbcontext.Employees.FindAsync(id);
            if (employee == null)   
            {
                return NotFound();
            }
            return Ok(employee);
        }

        [HttpPost]
        public async Task<IActionResult> AddEmloyee(AddEmployee addemployee)
        {
            var employee = new Employee()
            {
                Id = Guid.NewGuid(),
                Name = addemployee.Name,
                Department = addemployee.Department,
                Phone = addemployee.Phone
            };
            await dbcontext.Employees.AddAsync(employee);
            await dbcontext.SaveChangesAsync();
            return Ok(employee);
        }

        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdateEmployee([FromRoute] Guid id, UpdateEmployee updateEmployee)
        {
            var employee = await dbcontext.Employees.FindAsync(id);
            if(employee != null)
            {
                employee.Name = updateEmployee.Name;
                employee.Department = updateEmployee.Department;
                employee.Phone = updateEmployee.Phone;
                await dbcontext.SaveChangesAsync();
                return Ok(employee);
            }
            return NotFound();
        }

        [HttpDelete]
        [Route("{id:guid}")]
        public async Task<IActionResult> DeleteEmployee(Guid id)
        {
            var employee = await dbcontext.Employees.FindAsync(id);
            if(employee != null)
            {
                dbcontext.Remove(employee);
                await dbcontext.SaveChangesAsync();
                return Ok(employee);
            }
            return NotFound();
        }

    }
}
